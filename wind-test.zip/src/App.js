import logo from './logo.svg';
import './App.css';
import React, { useContext, useEffect, useMemo, useReducer, useRef, useState } from 'react'
import { createPortal } from 'react-dom';

const PRODUCT_DATA = {
  10001: {
    id: 10001,
    name: '苹果',
    price: 10.99,
    number: 0,
    pic: 'https://img.alicdn.com/imgextra/i4/72255097/O1CN01UXYKxx1nWTf0xucaN_!!0-saturn_solar.jpg_580x580q90.jpg_.webp',
  },
  10002: {
    id: 10002,
    name: '香蕉',
    price: 20.99,
    number: 0,
    pic: 'https://img.alicdn.com/imgextra/i1/501910146/O1CN01TLFVnM1CwujjVgiSq_!!0-saturn_solar.jpg_580x580q90.jpg_.webp'
  },
  10003: {
    id: 10003,
    name: '菠萝-广西香蕉新鲜包熟包甜现摘现发',
    price: 30.99,
    number: 0,
    pic: 'https://g-search3.alicdn.com/img/bao/uploaded/i4/i2/2216316863464/O1CN01ZdVPWQ1bSYso666MM_!!2216316863464.jpg_580x580q90.jpg_.webp'
  },
  10004: {
    id: 10004,
    name: '榴莲',
    price: 40.99,
    number: 0,
    pic: 'https://img.alicdn.com/imgextra/i4/112939304/O1CN01i52LlV2IbHubqltkm_!!0-saturn_solar.jpg_580x580q90.jpg_.webp'
  },
  10005: {
    id: 10005,
    name: '橙子-现摘正宗赣南脐橙赣州产地直发江西10斤装大果当季新鲜水果',
    price: 50.99,
    number: 0,
    pic: 'https://g-search3.alicdn.com/img/bao/uploaded/i4/i4/2212983285827/O1CN019djKA31suolbhSyuQ_!!2212983285827.jpg_580x580q90.jpg_.webp'
  },
}

const ProductContext = React.createContext()

function reducer(state, action) {
  if (action.type === 'add') {
    state[action.id].number++;
    return { ...state }
  }

  if (action.type === 'decrease') {
    state[action.id].number--;
    return { ...state }
  }
}

function ProductList() {
  return <div className='content'>
    {Object.values(PRODUCT_DATA).map(i => {
      return <ProductItem key={i.id} data={i} />
    })}
  </div>
}

function ProductItem({ data }) {
  const dispatch = useContext(ProductContext)

  const handleAdd = () => {
    dispatch({ type: 'add', id: data.id })
  }

  return (
    <div className='item'>
      <img src={data.pic} />
      <div className='item-content'>
        <div className='item-desc'>
          <div className='item-name' title={data.name}>{data.name}</div>
          <div className='item-price'>{data.price}</div>
        </div>
        <div
          className='item-add handleShopping'
          onClick={handleAdd}
        >
          加入购物车
        </div>
      </div>
    </div>
  )
}

function TotalPrice({ data, submit }) {
  const [open, setOpen] = useState(false)

  useEffect(() => {
    if (submit.t) {
      setOpen(true)
    }
  }, [submit])

  const handleClose = () => {
    setOpen(false)
  }
 
  return (
  <>
    {open && createPortal((
      <>
      <div className='mask'></div>
      <div className='dialog handleShopping'>
        <div className='dialog-close' onClick={handleClose}>x</div>
        <div className='dialog-content'>
          {`商品总价${Object.values(data).reduce((prev, curr) => {
            return (Number(prev) + Number(curr.price * curr.number)).toFixed(2)
          }, 0) || 0}`}
        </div>
      </div>
      </>
    ), document.body, 'totalprice')}
  </>
  )
}

function ShoppingCart({data}) {
  const dispatch = useContext(ProductContext)
  const [submit, setSubmit] = useState({t: null})

  const handleDelete = (id) => {
    dispatch({ type: 'decrease', id })
  }

  const handleBuy = () => {
    setSubmit({ t: new Date().getTime() })
  }

  return (
    <div className='shopping handleShopping'>
        {Object.values(data).filter(i => i.number > 0).map(i => {
          return (
            <div className='shopping-item' key={i.id}>
              <div className='shopping-name' title={i.name}>{i.name}</div>
              <div className='shopping-right'>
                <div className='shopping-price'>{`${Number(i.price).toFixed(2)}x${i.number}`}</div>
                <div className='shopping-delete' onClick={() => handleDelete(i.id)}>删除</div>
              </div>
            </div>
          )
        })}
      <div className='shopping-buy' onClick={handleBuy}>购买</div>
      <TotalPrice data={data} submit={submit}/>
    </div>
  )
}

function App() {
  const [state, dispatch] = useReducer(reducer, PRODUCT_DATA)
  const shoppingRef = useRef(null)
  const [openCart, setOpenCart] = useState(false)

  const count = useMemo(() => {
    return Object.values(state).reduce((prev, curr) => {
      return prev + curr.number
    }, 0)
  }, [state])

  const handleCheck = () => {
    if (count === 0) return;
    setOpenCart(true)
  }
  
  useEffect(() => {
    function handleCloseShopping(e) {
      const cDom = document.querySelectorAll('.handleShopping')
      const tDom = e.target
      console.log('handleCloseShopping', cDom, tDom)
      if (cDom === tDom || Array(...cDom)?.some(i => i.contains(tDom))) {
        console.log('contain', cDom, tDom)
        //
      } else {
        console.log('close', cDom, tDom)
        setOpenCart(false)
      }
    }
    document.addEventListener('click', handleCloseShopping)
    return () => document.removeEventListener('click', handleCloseShopping)
  }, [])

  return (
    <ProductContext.Provider value={dispatch}>
      <div className="App">
        <header className="header">
          <div className='title'>购物天堂</div>
          <div
            className='option handleShopping'
            ref={shoppingRef}
            onMouseEnter={handleCheck}
          >
            🛒 购物车{`(${count})`}
          </div>
          {(shoppingRef.current && openCart) &&
            createPortal(<ShoppingCart data={state}/>, shoppingRef.current, 'shop')
          }
        </header>
        <ProductList />
      </div>
    </ProductContext.Provider>
  );
}

export default App;
